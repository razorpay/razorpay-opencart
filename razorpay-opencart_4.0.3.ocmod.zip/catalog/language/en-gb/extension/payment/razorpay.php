<?php
// Text
$_['text_title'] = 'Pay by Razorpay <br> <a href="https://www.razorpay.com" target="_blank"><img src="https://cdn.razorpay.com/static/assets/logo/payment_method.svg" alt="Razorpay" title="Razorpay" style="border: 1px solid #EEEEEE;margin-top: 5px" /></a>';

